# Farshore Phase 2

Open `Farshore Context and Assisment/docs/assignment/phase2/README.md` for the package guide.
Open that folder's `index.html` for the offline design reference.

The design packet covers the architecture, five user flows, edge cases and 26 wireframes.
The editable PowerPoint has 12 slides and a 10-minute speaking plan. A PDF copy is included.
The separate one-page technical spike summary accompanies the raw results of six real local AI calls and deliberate failures.

Before submission, review the contribution statement and collect actual class peer critique.
Persona references are Phase 1 sketches. Proposed controls are labeled as design work.

The archive preserves relative source links. Supporting source excerpts and authoring scripts are included for traceability.
This is a design submission package, not a complete game installation or model download.
Reproduction instructions assume the original project checkout, Node dependencies, Windows Arial fonts and PowerPoint.
PDF authoring requires reportlab; validation requires pypdf. Credentials, model weights, installed dependencies and private build files are excluded.
